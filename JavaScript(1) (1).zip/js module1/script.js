console.log("java script is connected");
let birthYearInput = document.getElementById("birthYear");
let button = document.getElementById("calculationBtn");
let result = document.getElementById("result");

button.addEventListener("click", function(){
    let birthYear = birthYearInput.value;
    if(birthYear === ""){
        result.textContent = "Please enter your birth year.";
        return;
    }
    let age = 2026 - birthYear;
    result.textContent = "Your age is: " + age;
})